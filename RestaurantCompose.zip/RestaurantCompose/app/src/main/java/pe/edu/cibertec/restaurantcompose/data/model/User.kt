package pe.edu.cibertec.restaurantcompose.data.model

class User(
    val username: String,
    val password: String
)